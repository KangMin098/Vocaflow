// apps/web/src/lib/srs/index.ts
// Vocaflow Web — SRS 엔진 진입점
// 핵심 로직은 @vocaflow/ui-shared/srs에 위치 (웹·모바일 공유)
// CLAUDE.md §17 학습 모델 v2.0 [4] 기억 축

// 모든 공개 API 재export — 사용처는 '@/lib/srs'만 import
export {
  // 타입
  Rating,
  type SrsCard,
  type MemoryState,
  type RatingValue,
  type ModuleId,
  type MasteryLevel,
  type UserStats,
  type ReviewInput,
  type ReviewResult,

  // 상태 계산
  MEMORY_THRESHOLD,
  calculateRetrievability,
  getMemoryState,
  getRetrievability,
  filterUrgentCards,
  getMemoryColorVar,

  // FSRS 엔진
  VOCAFLOW_DEFAULT_PARAMS,
  buildVocaflowParams,
  createVocaflowScheduler,
  applyReview,
  previewRatings,
  createNewCard,
} from '@vocaflow/ui-shared/srs';
