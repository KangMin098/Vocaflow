// apps/web/src/components/game/wordblitz/PlushieModel.tsx
// 인형 GLB 로더 + sphere 폴백
//
// v4.2 변경:
//   - emissive 적용 제거 → GLB 원본 색상 유지
//   - 정답 표시는 외부 글로우 ring(Plushie.tsx)에 위임

'use client';

import { useGLTF } from '@react-three/drei';
import { ErrorBoundary } from 'react-error-boundary';
import { Suspense, useMemo } from 'react';
import * as THREE from 'three';
import type { PlushieType } from '@/lib/wordblitz/data';

interface PlushieModelProps {
  type: PlushieType;
  isTarget: boolean;
}

const PLUSHIE_TARGET_HEIGHT = 1.0;

function PlushieGLB({ type }: PlushieModelProps) {
  if (!type.modelUrl) {
    throw new Error('No modelUrl');
  }

  const { scene } = useGLTF(type.modelUrl);

  const cloned = useMemo(() => {
    const clone = scene.clone(true);

    const box = new THREE.Box3().setFromObject(clone);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());

    if (size.y > 0 && isFinite(size.y)) {
      const scale = PLUSHIE_TARGET_HEIGHT / size.y;
      clone.scale.setScalar(scale);

      clone.position.x = -center.x * scale;
      clone.position.y = -box.min.y * scale;
      clone.position.z = -center.z * scale;
    }

    // 그림자만 활성화 - 머티리얼은 GLB 원본 그대로
    clone.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
        // emissive 적용 안 함
      }
    });

    return clone;
  }, [scene]);

  return <primitive object={cloned} />;
}

function PlushieFallback({ type }: PlushieModelProps) {
  const radius = 0.5;

  return (
    <group>
      <mesh position={[0, radius, 0]} castShadow receiveShadow>
        <sphereGeometry args={[radius, 24, 24]} />
        <meshStandardMaterial
          color={type.color}
          roughness={0.7}
          metalness={0.05}
        />
      </mesh>

      <mesh position={[-0.15, radius + 0.05, 0.42]}>
        <sphereGeometry args={[0.06, 12, 12]} />
        <meshBasicMaterial color={0x1A0F0A} />
      </mesh>
      <mesh position={[0.15, radius + 0.05, 0.42]}>
        <sphereGeometry args={[0.06, 12, 12]} />
        <meshBasicMaterial color={0x1A0F0A} />
      </mesh>
    </group>
  );
}

export function PlushieModel(props: PlushieModelProps) {
  if (!props.type.modelUrl) {
    return <PlushieFallback {...props} />;
  }

  return (
    <ErrorBoundary fallback={<PlushieFallback {...props} />}>
      <Suspense fallback={<PlushieFallback {...props} />}>
        <PlushieGLB {...props} />
      </Suspense>
    </ErrorBoundary>
  );
}
