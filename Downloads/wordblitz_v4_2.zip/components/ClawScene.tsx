// apps/web/src/components/game/wordblitz/ClawScene.tsx
// 전체 3D 씬 - 박스 + 콘솔 + 라이팅 + 집게 + 인형들
//
// v4.2 변경:
//   - 카메라 Y 위로 (3 → 4.5) + 거리 멀리 (8.5 → 12) → 박스 + 콘솔 모두 보임
//   - 컬러 PointLight 제거 → 자연스러운 흰색 라이팅
//   - 조이스틱 + DROP 버튼 ref 연결

'use client';

import { Suspense, useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { ClawMachine, MACHINE } from './ClawMachine';
import { ClawModel } from './ClawModel';
import { Plushie } from './Plushie';
import type { GameState, LiveClawState, ClawTargets } from '@/lib/wordblitz/types';

interface ClawSceneProps {
  state: GameState;
  liveStateRef: React.MutableRefObject<LiveClawState>;
  targetsRef: React.MutableRefObject<ClawTargets>;
  updatePhysics: (dt: number) => void;
}

function PhysicsUpdater({ updatePhysics }: { updatePhysics: (dt: number) => void }) {
  useFrame((_, delta) => {
    updatePhysics(delta);
  });
  return null;
}

// 조이스틱 기울기 + DROP 버튼 상태 sync
function ConsoleStateSync({
  liveStateRef,
  targetsRef,
  joystickTilt,
  dropPressed,
  isDropping,
}: {
  liveStateRef: React.MutableRefObject<LiveClawState>;
  targetsRef: React.MutableRefObject<ClawTargets>;
  joystickTilt: React.MutableRefObject<number>;
  dropPressed: React.MutableRefObject<number>;
  isDropping: boolean;
}) {
  useFrame(() => {
    // 조이스틱 = 집게 X 위치 (-1 ~ 1)
    joystickTilt.current = liveStateRef.current.clawX;

    // DROP 버튼 = 하강 중일 때 눌림
    dropPressed.current = isDropping ? 1 : 0;
  });
  return null;
}

function BackgroundStars() {
  const geometryRef = useRef<THREE.BufferGeometry>(null);

  useEffect(() => {
    if (!geometryRef.current) return;
    const positions = new Float32Array(300 * 3);
    for (let i = 0; i < 300; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 60;
      positions[i * 3 + 1] = Math.random() * 20;
      positions[i * 3 + 2] = -10 - Math.random() * 8;
    }
    geometryRef.current.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  }, []);

  return (
    <points>
      <bufferGeometry ref={geometryRef} />
      <pointsMaterial color={0xFFFFFF} size={0.04} sizeAttenuation />
    </points>
  );
}

function SceneContent({ state, liveStateRef, targetsRef, updatePhysics }: ClawSceneProps) {
  const grabbedPlushieRef = useRef<THREE.Group | null>(null);

  // 조이스틱/DROP 버튼 ref (ClawMachine에 전달)
  const joystickTiltRef = useRef(0);
  const dropPressedRef = useRef(0);

  const isDropping = state.phase === 'dropping' || state.phase === 'grabbing';

  return (
    <>
      <PhysicsUpdater updatePhysics={updatePhysics} />
      <ConsoleStateSync
        liveStateRef={liveStateRef}
        targetsRef={targetsRef}
        joystickTilt={joystickTiltRef}
        dropPressed={dropPressedRef}
        isDropping={isDropping}
      />

      {/* ═══════ 자연스러운 흰색 라이팅 (컬러 라이트 제거) ═══════ */}
      <ambientLight color={0xFFFFFF} intensity={0.7} />

      {/* 천장 spotlight */}
      <spotLight
        color={0xFFFFFF}
        intensity={120}
        position={[0, 7, 0]}
        angle={Math.PI / 3}
        penumbra={0.5}
        decay={1.2}
        distance={15}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0005}
        target-position={[0, 0, 0]}
      />

      {/* 정면 fill (흰색만) */}
      <directionalLight color={0xFFFFFF} intensity={0.6} position={[0, 4, 8]} />

      {/* 위쪽 라이트 (집게 잘 보이게) */}
      <directionalLight color={0xFFFFFF} intensity={0.5} position={[0, 8, 4]} />

      {/* 좌측 부드러운 fill */}
      <directionalLight color={0xFFFFFF} intensity={0.3} position={[-4, 3, 4]} />

      {/* 콘솔 하단 라이트 (콘솔 잘 보이게) */}
      <pointLight color={0xFFFFFF} intensity={20} distance={6} position={[0, -1, 4]} />

      {/* ═══════ 배경 (우주) ═══════ */}
      <BackgroundStars />

      <mesh position={[0, 5, -8]} receiveShadow>
        <planeGeometry args={[60, 30]} />
        <meshStandardMaterial color={0x0E0A1F} roughness={0.95} />
      </mesh>

      {/* ═══════ 인형뽑기 박스 + 콘솔 ═══════ */}
      <ClawMachine joystickTilt={joystickTiltRef} dropPressed={dropPressedRef} />

      {/* ═══════ 집게 ═══════ */}
      <Suspense fallback={null}>
        <ClawModel
          liveStateRef={liveStateRef}
          grabbedPlushieRef={grabbedPlushieRef}
        />
      </Suspense>

      {/* ═══════ 인형들 ═══════ */}
      {state.plushies.map((plushie) => (
        <Plushie
          key={plushie.id}
          data={plushie}
          isGrabbed={state.grabbedPlushieId === plushie.id}
          ref={state.grabbedPlushieId === plushie.id ? grabbedPlushieRef : undefined}
        />
      ))}
    </>
  );
}

export function ClawScene({ state, liveStateRef, targetsRef, updatePhysics }: ClawSceneProps) {
  return (
    <Canvas
      // 카메라 - 박스(Y=0~7) + 콘솔(Y=-2.4~-0.85) 모두 보이게
      // Y=4.5: 박스 중앙 + 콘솔 보임
      // Z=12: 충분히 떨어져서 전체 보기
      camera={{
        position: [0, 4.5, 12],
        fov: 38,
        near: 0.1,
        far: 100,
      }}
      shadows
      gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        background: 'linear-gradient(135deg, #1a0530 0%, #4a1080 50%, #1a0530 100%)',
      }}
      onCreated={({ camera }) => {
        // 박스 중앙(Y=2.5) 향하도록 - 박스 + 콘솔 균형
        camera.lookAt(0, 2.5, 0);
      }}
    >
      <fog attach="fog" args={[0x1a0530, 20, 45]} />
      <SceneContent
        state={state}
        liveStateRef={liveStateRef}
        targetsRef={targetsRef}
        updatePhysics={updatePhysics}
      />
    </Canvas>
  );
}
