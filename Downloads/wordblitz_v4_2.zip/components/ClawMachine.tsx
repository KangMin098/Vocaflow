// apps/web/src/components/game/wordblitz/ClawMachine.tsx
// 인형뽑기 기계 박스 + 하단 콘솔 (조이스틱 + DROP 버튼)
//
// v4.2 변경:
//   - 내부 바닥 분홍 → 베이지 (인형 색상 자연스럽게)
//   - 하단 콘솔 추가 (빨간 패널 + 조이스틱 + DROP)
//   - 조이스틱은 게임 상태에 따라 기울어짐 (joystickTilt prop)

'use client';

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export const MACHINE = {
  width: 7,
  height: 7,
  depth: 3.4,
  wallThickness: 0.2,
  innerXMin: -3.0,
  innerXMax: 3.0,
  innerZMin: -1.3,
  innerZMax: 1.3,
  innerYMax: 6,
  clawHomeY: 5.8,
  clawDropY: 1.5,
  clawXRange: 2.5,
  // 콘솔 (박스 아래)
  consoleHeight: 1.5,
  consoleY: -1.6,    // 콘솔 중심 Y
  consoleDepth: 2.0,
} as const;

interface ClawMachineProps {
  /** 조이스틱 기울기 (-1 ~ 1, 게임 상태와 연동) */
  joystickTilt?: React.MutableRefObject<number>;
  /** DROP 버튼 눌림 (0 ~ 1) */
  dropPressed?: React.MutableRefObject<number>;
}

export function ClawMachine({ joystickTilt, dropPressed }: ClawMachineProps = {}) {
  const signMatRef = useRef<THREE.MeshStandardMaterial>(null);
  const stickGroupRef = useRef<THREE.Group>(null);
  const dropButtonRef = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    // LED 사인 깜박임
    if (signMatRef.current) {
      signMatRef.current.emissiveIntensity = 0.5 + Math.sin(clock.elapsedTime * 2) * 0.2;
    }

    // 조이스틱 기울기
    if (stickGroupRef.current && joystickTilt) {
      const target = joystickTilt.current * 0.4; // -0.4 ~ 0.4 rad
      stickGroupRef.current.rotation.z += (target - stickGroupRef.current.rotation.z) * 0.2;
    }

    // DROP 버튼 눌림
    if (dropButtonRef.current && dropPressed) {
      const target = dropPressed.current > 0.5 ? -0.05 : 0;
      dropButtonRef.current.position.y += (target - dropButtonRef.current.position.y) * 0.3;
    }
  });

  // VOCAFLOW LED 사인
  const signTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#FFD93D';
    ctx.fillRect(0, 0, 1024, 256);

    ctx.font = 'bold 110px Bungee, cursive';
    ctx.fillStyle = '#1a0530';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('VOCAFLOW', 512, 128);

    const tex = new THREE.CanvasTexture(canvas);
    tex.needsUpdate = true;
    return tex;
  }, []);

  // DROP 버튼 텍스트
  const dropTextTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, 256, 256);

    ctx.font = 'bold 50px Bungee, cursive';
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.6)';
    ctx.shadowBlur = 6;
    ctx.fillText('DROP!', 128, 128);

    const tex = new THREE.CanvasTexture(canvas);
    tex.needsUpdate = true;
    return tex;
  }, []);

  const w = MACHINE.width / 2;
  const h = MACHINE.height;
  const d = MACHINE.depth / 2;
  const cy = MACHINE.consoleY;
  const cd = MACHINE.consoleDepth / 2;

  return (
    <group>
      {/* ═══════════════════════════════════════════
          BOX 부분 (위)
          ═══════════════════════════════════════════ */}

      {/* 외부 베이스 (검정 받침대) */}
      <mesh position={[0, -0.2, 0]} receiveShadow>
        <boxGeometry args={[MACHINE.width + 0.4, 0.4, MACHINE.depth + 0.4]} />
        <meshStandardMaterial color={0x1a1a1a} roughness={0.6} metalness={0.4} />
      </mesh>

      {/* 내부 바닥 (베이지 - 인형 색상 자연스럽게) */}
      <mesh position={[0, 0.05, 0]} receiveShadow>
        <boxGeometry args={[MACHINE.width - 0.3, 0.1, MACHINE.depth - 0.3]} />
        <meshStandardMaterial color={0xF5F0E8} roughness={0.7} metalness={0.05} />
      </mesh>

      {/* 좌측 빨간 프레임 */}
      <mesh position={[-w, h / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.2, h, MACHINE.depth]} />
        <meshStandardMaterial color={0xE63946} roughness={0.4} metalness={0.5} />
      </mesh>

      {/* 우측 빨간 프레임 */}
      <mesh position={[w, h / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.2, h, MACHINE.depth]} />
        <meshStandardMaterial color={0xE63946} roughness={0.4} metalness={0.5} />
      </mesh>

      {/* 뒤쪽 어두운 벽 */}
      <mesh position={[0, h / 2, -d]} receiveShadow>
        <boxGeometry args={[MACHINE.width, h, 0.2]} />
        <meshStandardMaterial color={0x2A1A4A} roughness={0.7} />
      </mesh>

      {/* 천장 */}
      <mesh position={[0, h, 0]} castShadow>
        <boxGeometry args={[MACHINE.width, 0.2, MACHINE.depth]} />
        <meshStandardMaterial color={0xE63946} roughness={0.4} metalness={0.5} />
      </mesh>

      {/* 앞쪽 유리창 */}
      <mesh position={[0, h / 2, d]}>
        <planeGeometry args={[MACHINE.width - 0.4, h - 0.4]} />
        <meshPhysicalMaterial
          color={0xFFFFFF}
          metalness={0}
          roughness={0.05}
          transmission={0.95}
          opacity={0.1}
          transparent
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* LED 사인 */}
      <mesh position={[0, h + 0.3, d - 0.1]}>
        <boxGeometry args={[MACHINE.width - 0.3, 0.5, 0.15]} />
        <meshStandardMaterial
          ref={signMatRef}
          color={0xFFD93D}
          emissive={0xFFD93D}
          emissiveIntensity={0.6}
          roughness={0.3}
        />
      </mesh>

      <mesh position={[0, h + 0.3, d - 0.01]}>
        <planeGeometry args={[MACHINE.width - 0.4, 0.45]} />
        <meshBasicMaterial map={signTexture} />
      </mesh>

      {/* ═══════════════════════════════════════════
          CONSOLE 부분 (아래) - 신규
          ═══════════════════════════════════════════ */}

      {/* 콘솔 본체 (빨간 박스, 박스 아래) */}
      <mesh position={[0, cy, d - cd / 2]} castShadow receiveShadow>
        <boxGeometry args={[MACHINE.width + 0.4, MACHINE.consoleHeight, MACHINE.consoleDepth]} />
        <meshStandardMaterial color={0xC8232E} roughness={0.4} metalness={0.4} />
      </mesh>

      {/* 콘솔 윗면 하이라이트 (살짝 밝은 빨강) */}
      <mesh position={[0, cy + MACHINE.consoleHeight / 2 - 0.05, d - cd / 2]}>
        <boxGeometry args={[MACHINE.width + 0.35, 0.1, MACHINE.consoleDepth - 0.05]} />
        <meshStandardMaterial color={0xE63946} roughness={0.4} metalness={0.4} />
      </mesh>

      {/* 콘솔 앞면 베벨 (빨간 더 어두운 라인) */}
      <mesh position={[0, cy - MACHINE.consoleHeight / 2 + 0.05, d - 0.05]}>
        <boxGeometry args={[MACHINE.width + 0.4, 0.1, 0.02]} />
        <meshStandardMaterial color={0x8B1820} roughness={0.5} />
      </mesh>

      {/* ────── 좌측 보라 패널 + 작은 빨간 버튼 2개 ────── */}
      <mesh position={[-2.0, cy + 0.15, d - 0.4]} castShadow>
        <boxGeometry args={[1.4, 0.3, 1.0]} />
        <meshStandardMaterial color={0x2A1A4A} roughness={0.5} metalness={0.3} />
      </mesh>

      {/* 좌측 작은 버튼 1 */}
      <mesh position={[-2.3, cy + 0.35, d - 0.4]} castShadow>
        <cylinderGeometry args={[0.18, 0.18, 0.15, 16]} />
        <meshStandardMaterial color={0xE63946} roughness={0.3} metalness={0.2} />
      </mesh>
      {/* 좌측 작은 버튼 2 */}
      <mesh position={[-1.7, cy + 0.35, d - 0.4]} castShadow>
        <cylinderGeometry args={[0.18, 0.18, 0.15, 16]} />
        <meshStandardMaterial color={0xE63946} roughness={0.3} metalness={0.2} />
      </mesh>

      {/* ────── 중앙 조이스틱 ────── */}
      {/* 보라 패널 (조이스틱 베이스) */}
      <mesh position={[0, cy + 0.15, d - 0.4]} castShadow>
        <boxGeometry args={[1.6, 0.3, 1.0]} />
        <meshStandardMaterial color={0x2A1A4A} roughness={0.5} metalness={0.3} />
      </mesh>

      {/* 조이스틱 검정 베이스 (구멍) */}
      <mesh position={[0, cy + 0.32, d - 0.4]}>
        <cylinderGeometry args={[0.32, 0.4, 0.12, 24]} />
        <meshStandardMaterial color={0x0A0512} roughness={0.6} metalness={0.4} />
      </mesh>

      {/* 검정 hole */}
      <mesh position={[0, cy + 0.39, d - 0.4]}>
        <cylinderGeometry args={[0.22, 0.22, 0.04, 24]} />
        <meshStandardMaterial color={0x000000} roughness={0.9} />
      </mesh>

      {/* 조이스틱 stick + ball (회전 그룹) */}
      <group ref={stickGroupRef} position={[0, cy + 0.40, d - 0.4]}>
        {/* Stick (검은 막대) */}
        <mesh position={[0, 0.35, 0]} castShadow>
          <cylinderGeometry args={[0.07, 0.09, 0.7, 16]} />
          <meshStandardMaterial color={0x111118} roughness={0.5} metalness={0.6} />
        </mesh>

        {/* 빨간 공 (stick 위 일체형) */}
        <mesh position={[0, 0.85, 0]} castShadow>
          <sphereGeometry args={[0.28, 32, 24]} />
          <meshStandardMaterial
            color={0xE63946}
            roughness={0.25}
            metalness={0.15}
          />
        </mesh>
      </group>

      {/* ────── 우측 DROP 버튼 ────── */}
      {/* 보라 패널 */}
      <mesh position={[2.0, cy + 0.15, d - 0.4]} castShadow>
        <boxGeometry args={[1.4, 0.3, 1.0]} />
        <meshStandardMaterial color={0x2A1A4A} roughness={0.5} metalness={0.3} />
      </mesh>

      {/* 검정 베이스 */}
      <mesh position={[2.0, cy + 0.32, d - 0.4]}>
        <cylinderGeometry args={[0.42, 0.46, 0.12, 24]} />
        <meshStandardMaterial color={0x0A0512} roughness={0.6} metalness={0.4} />
      </mesh>

      {/* 빨간 큰 버튼 (눌림 애니메이션) */}
      <mesh ref={dropButtonRef} position={[2.0, cy + 0.45, d - 0.4]} castShadow>
        <cylinderGeometry args={[0.36, 0.36, 0.18, 24]} />
        <meshStandardMaterial color={0xE63946} roughness={0.3} metalness={0.2} />
      </mesh>

      {/* DROP! 텍스트 (버튼 위) */}
      <mesh position={[2.0, cy + 0.55, d - 0.4]} rotation={[-Math.PI / 2, 0, -0.1]}>
        <planeGeometry args={[0.55, 0.55]} />
        <meshBasicMaterial map={dropTextTexture} transparent depthWrite={false} />
      </mesh>
    </group>
  );
}
