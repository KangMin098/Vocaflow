// apps/web/src/app/(auth)/signup/page.tsx
// 회원가입 페이지 — Phase 1.5 화면 설계 단계
// 목업 데이터 사용 (실제 Supabase 연결은 Phase 2에서)

"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Mail, Lock, User, Check, ChevronRight } from "lucide-react";

import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { FormField } from "@/components/ui/FormField";
import { Checkbox } from "@/components/ui/Checkbox";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { useToast } from "@/components/ui/Toast";

// ══════════════════════════════════════════════════════════════
// 비밀번호 강도 측정 (간단 휴리스틱)
// ══════════════════════════════════════════════════════════════
type PasswordStrength = {
  score: number; // 0~4
  label: string;
  color: "error" | "warning" | "success";
};

function getPasswordStrength(password: string): PasswordStrength {
  if (!password) return { score: 0, label: "", color: "error" };

  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  // 0~5 → 0~4로 정규화
  score = Math.min(score, 4);

  if (score <= 1) return { score, label: "약함", color: "error" };
  if (score === 2) return { score, label: "보통", color: "warning" };
  if (score === 3) return { score, label: "좋음", color: "success" };
  return { score, label: "강함", color: "success" };
}

// 이메일 형식 검증
function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// ══════════════════════════════════════════════════════════════
// Page
// ══════════════════════════════════════════════════════════════
export default function SignupPage() {
  const router = useRouter();
  const toast = useToast();

  // 폼 상태
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [agreePrivacy, setAgreePrivacy] = useState(false);
  const [agreeMarketing, setAgreeMarketing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // 비밀번호 강도
  const passwordStrength = useMemo(
    () => getPasswordStrength(password),
    [password],
  );

  // 검증
  const emailError =
    submitted && !email
      ? "이메일을 입력하세요."
      : submitted && email && !isValidEmail(email)
        ? "올바른 이메일 형식이 아닙니다."
        : undefined;

  const passwordError =
    submitted && !password
      ? "비밀번호를 입력하세요."
      : submitted && password.length < 8
        ? "비밀번호는 8자 이상이어야 합니다."
        : undefined;

  const termsError =
    submitted && (!agreeTerms || !agreePrivacy)
      ? "필수 약관에 동의해주세요."
      : undefined;

  // Google 가입 핸들러 (목업)
  const handleGoogleSignup = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("Google 가입 (목업) — Phase 2에서 실제 연결됩니다");
    }, 1000);
  };

  // 이메일 가입 핸들러 (목업)
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    if (
      !email ||
      !password ||
      !isValidEmail(email) ||
      password.length < 8 ||
      !agreeTerms ||
      !agreePrivacy
    ) {
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("회원가입 완료! 이메일을 확인해주세요.", {
        title: "환영합니다 🎉",
      });
      router.push("/verify-email");
    }, 1500);
  };

  return (
    <Card padding="lg">
      {/* ── 헤더 ── */}
      <div className="text-center mb-s-6">
        <h1 className="font-display text-2xl font-extrabold text-t1 mb-s-2">
          회원가입
        </h1>
        <p className="font-body text-sm text-t2">
          영어 학습을 시작하세요
        </p>
      </div>

      {/* ── Google 가입 ── */}
      <Button
        variant="social"
        size="md"
        fullWidth
        onClick={handleGoogleSignup}
        disabled={loading}
        leftIcon={
          <svg width="18" height="18" viewBox="0 0 18 18">
            <g fill="none">
              <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4" />
              <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z" fill="#34A853" />
              <path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05" />
              <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335" />
            </g>
          </svg>
        }
      >
        Google로 계속하기
      </Button>

      {/* ── 구분선 ── */}
      <div className="flex items-center gap-s-3 my-s-6">
        <div className="flex-1 h-px bg-bd" />
        <span className="font-mono text-xs text-t3 uppercase tracking-wider">
          또는 이메일로
        </span>
        <div className="flex-1 h-px bg-bd" />
      </div>

      {/* ── 이메일 가입 폼 ── */}
      <form onSubmit={handleSubmit} className="space-y-s-4">
        {/* 이메일 */}
        <FormField
          label="이메일"
          required
          error={emailError}
          helper={!emailError ? "로그인에 사용됩니다" : undefined}
        >
          {(props) => (
            <Input
              type="email"
              placeholder="user@vocaflow.com"
              prefix={<Mail size={16} />}
              state={emailError ? "error" : "default"}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              {...props}
            />
          )}
        </FormField>

        {/* 비밀번호 */}
        <div>
          <FormField
            label="비밀번호"
            required
            error={passwordError}
            helper={
              !passwordError && !password
                ? "8자 이상, 숫자·대소문자 조합 권장"
                : undefined
            }
          >
            {(props) => (
              <Input
                type="password"
                placeholder="비밀번호"
                prefix={<Lock size={16} />}
                showPasswordToggle
                state={passwordError ? "error" : "default"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                {...props}
              />
            )}
          </FormField>

          {/* 비밀번호 강도 표시 */}
          {password && !passwordError && (
            <div className="mt-s-2 space-y-s-1">
              <ProgressBar
                value={passwordStrength.score}
                max={4}
                color={passwordStrength.color}
                size="xs"
              />
              <p
                className={`font-mono text-xs text-right ${
                  passwordStrength.color === "error"
                    ? "text-error"
                    : passwordStrength.color === "warning"
                      ? "text-warning"
                      : "text-success"
                }`}
              >
                강도: {passwordStrength.label}
              </p>
            </div>
          )}
        </div>

        {/* 이름 (선택) */}
        <FormField label="이름" hint="선택">
          {(props) => (
            <Input
              placeholder="홍길동"
              prefix={<User size={16} />}
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
              {...props}
            />
          )}
        </FormField>

        {/* 약관 동의 */}
        <div className="space-y-s-2 pt-s-2">
          <Checkbox
            label={
              <span>
                <span className="text-error mr-s-1">*</span>
                이용약관에 동의합니다
                <Link
                  href="/terms"
                  target="_blank"
                  className="ml-s-2 text-p underline text-sm"
                  onClick={(e) => e.stopPropagation()}
                >
                  보기
                </Link>
              </span>
            }
            checked={agreeTerms}
            onChange={(e) => setAgreeTerms(e.target.checked)}
            error={!!termsError && !agreeTerms}
          />
          <Checkbox
            label={
              <span>
                <span className="text-error mr-s-1">*</span>
                개인정보 처리방침에 동의합니다
                <Link
                  href="/privacy"
                  target="_blank"
                  className="ml-s-2 text-p underline text-sm"
                  onClick={(e) => e.stopPropagation()}
                >
                  보기
                </Link>
              </span>
            }
            checked={agreePrivacy}
            onChange={(e) => setAgreePrivacy(e.target.checked)}
            error={!!termsError && !agreePrivacy}
          />
          <Checkbox
            label="마케팅 정보 수신 동의 (선택)"
            description="이벤트, 프로모션, 학습 팁을 이메일로 받습니다"
            checked={agreeMarketing}
            onChange={(e) => setAgreeMarketing(e.target.checked)}
          />

          {termsError && (
            <p className="font-body text-sm text-error">{termsError}</p>
          )}
        </div>

        {/* 가입 버튼 */}
        <Button
          type="submit"
          variant="primary"
          size="lg"
          fullWidth
          loading={loading}
          rightIcon={!loading ? <ChevronRight size={18} /> : undefined}
        >
          가입하기
        </Button>
      </form>

      {/* ── 로그인 링크 ── */}
      <div className="mt-s-6 text-center">
        <span className="font-body text-sm text-t2">
          이미 계정이 있으신가요?{" "}
        </span>
        <Link
          href="/login"
          className="font-body text-sm text-p font-semibold hover:underline"
        >
          로그인
        </Link>
      </div>
    </Card>
  );
}
