// apps/web/src/app/(auth)/layout.tsx
// 인증 라우트 그룹 공통 레이아웃
// - 헤더/푸터 없음, 로고만
// - 다크모드 지원
// - 모바일 우선 반응형

"use client";

import Link from "next/link";
import { Sparkles, ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const stored =
      (localStorage.getItem("vocaflow-theme") as "light" | "dark") || "light";
    setTheme(stored);
  }, []);

  const toggleTheme = () => {
    const next = theme === "light" ? "dark" : "light";
    setTheme(next);
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("vocaflow-theme", next);
  };

  return (
    <div className="min-h-screen bg-bg flex flex-col">
      {/* ── Top Bar (로고 + 테마 토글 + 뒤로) ── */}
      <header className="border-b border-bd bg-bg2/80 backdrop-blur-sm sticky top-0 z-30">
        <div className="max-w-page mx-auto px-s-4 py-s-3 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-s-2 text-t1 hover:opacity-80 transition-opacity duration-normal"
          >
            <ArrowLeft size={18} className="text-t2" />
            <Sparkles size={20} className="text-p" />
            <span className="font-display font-extrabold text-lg">Vocaflow</span>
          </Link>

          <button
            onClick={toggleTheme}
            aria-label={theme === "light" ? "다크 모드로 전환" : "라이트 모드로 전환"}
            className="px-s-3 py-s-2 rounded-md font-display font-semibold text-xs text-t2 hover:bg-bg3 transition-colors duration-normal"
          >
            {theme === "light" ? "🌙" : "☀️"}
          </button>
        </div>
      </header>

      {/* ── 메인 영역 (중앙 정렬) ── */}
      <main className="flex-1 flex items-start sm:items-center justify-center px-s-4 py-s-8 sm:py-s-12">
        <div className="w-full max-w-md">{children}</div>
      </main>

      {/* ── 푸터 (간단) ── */}
      <footer className="border-t border-bd py-s-4">
        <div className="max-w-page mx-auto px-s-4 flex items-center justify-center gap-s-4 font-mono text-xs text-t3">
          <Link href="/terms" className="hover:text-t2 transition-colors">
            이용약관
          </Link>
          <span>·</span>
          <Link href="/privacy" className="hover:text-t2 transition-colors">
            개인정보 처리방침
          </Link>
          <span>·</span>
          <span>© 2026 Vocaflow</span>
        </div>
      </footer>
    </div>
  );
}
